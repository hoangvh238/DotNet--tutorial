﻿using BussinessObject.Repository;
using Data_Access;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NewsWinApp
{
    public partial class frmHome : Form
    {
        NewsRepository newsRepository = new NewsRepository();
        public frmHome()
        {
            InitializeComponent();
        }

        private void frmHome_Load(object sender, EventArgs e)
        {
            var list = newsRepository.GetAllNews();
            BindingSource bindingSource = new BindingSource();
            bindingSource.DataSource = list;
            dgvNews.DataSource = bindingSource;

        }

        public News GetNews()
        {
            News news = null;
            try
            {
                int index = dgvNews.CurrentCell.RowIndex;
                var dummy = (News)dgvNews.Rows[index].DataBoundItem;
                news = newsRepository.GetNewsById(dummy.Id);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            return news;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            frmNewsDetail frmNewsDetail = new frmNewsDetail()
            {

                CreateOrUpdate = false,
            };
            frmNewsDetail.ShowDialog();

        }

        private void dgvNews_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            frmNewsDetail frmNewsDetail = new frmNewsDetail()
            {
                News = GetNews(),
                CreateOrUpdate = true,
            };
            frmNewsDetail.ShowDialog();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int index = dgvNews.CurrentCell.RowIndex;
            var dummy = (News)dgvNews.Rows[index].DataBoundItem;
            newsRepository.DeleteNews(dummy);
        }
    }
}
